<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['confirm_reset'])) {
    ?>
    <!DOCTYPE html>
    <html lang="tr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Veritabanı Sıfırlama Onayı</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
    <div class="app">
    <div class="container">
        <h1>Veritabanı Sıfırlama Onayı</h1>
        <p>DİKKAT: Bu işlem tüm veritabanını sıfırlayacak ve tüm verileri silecektir.</p>
        <form method="POST">
            <input type="hidden" name="confirm_reset" value="1">
            <input type="submit" value="Veritabanını Sıfırla" class="btn danger">
        </form>
        <p><a href="admin.php" class="btn">İptal</a></p>
    </div>
    </div>
    </body>
    </html>
    <?php
    exit();
}

try {
    $pdo->beginTransaction();

    $tables = ['order_items', '`order`', 'basket', 'food', 'comments', 'coupon', 'restaurant', 'users', 'company'];
    foreach ($tables as $table) {
        $pdo->exec("DROP TABLE IF EXISTS $table");
    }

    $sql = file_get_contents(__DIR__ . '/yedekinit.sql');
    $pdo->exec($sql);

    $pdo->commit();

    createDefaultAdminUser($pdo);

    $_SESSION['success_message'] = "Veritabanı başarıyla sıfırlandı ve yeniden oluşturuldu.";
    header("Location: admin.php");
    exit();
} catch (Exception $e) {
    $pdo->rollBack();
    $_SESSION['error_message'] = "Veritabanı sıfırlanırken bir hata oluştu: " . $e->getMessage();
    header("Location: admin.php");
    exit();
}
