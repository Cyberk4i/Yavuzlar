<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireRole('admin');

$commentId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?? 0;

if (deleteComment($pdo, $commentId)) {
    $_SESSION['success_message'] = "Yorum başarıyla silindi.";
} else {
    $_SESSION['error_message'] = "Yorum silinirken bir hata oluştu.";
}

header("Location: yorumListesi.php");
exit();
?>
