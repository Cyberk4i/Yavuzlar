<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireAdmin();


$companyId = isset($_GET['id']) ? intval($_GET['id']) : 0; 

if ($companyId > 0) {
    if (deleteCompany($pdo, $companyId)) {
        $_SESSION['success_message'] = "Firma başarıyla silindi.";
    } else {
        $_SESSION['error_message'] = "Firma silinirken bir hata oluştu. Lütfen tekrar deneyin.";
    }
} else {
    $_SESSION['error_message'] = "Geçersiz firma ID'si.";
}

header("Location: şirketListesi.php");
exit();
