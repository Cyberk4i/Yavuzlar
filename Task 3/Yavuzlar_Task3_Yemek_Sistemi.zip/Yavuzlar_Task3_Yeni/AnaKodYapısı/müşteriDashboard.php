<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireRole('customer');

$userId = $_SESSION['user_id'];
$userInfo = getUserById($pdo, $userId);

$recentOrders = getRecentOrdersByUserId($pdo, $userId, 5);

$popularRestaurants = getPopularRestaurants($pdo, 5);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Müşteri Paneli</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app">
<div class="container">
    <h1>Hoş Geldiniz, <?= htmlspecialchars($userInfo['name']) ?></h1>

    <h2>Son Siparişleriniz</h2>
    <?php if (empty($recentOrders)): ?>
        <p>Henüz sipariş vermediniz.</p>
    <?php else: ?>
        <ul>
            <?php foreach ($recentOrders as $order): ?>
                <li>
                    Sipariş #<?= $order['id'] ?> - 
                    <?= htmlspecialchars($order['restaurant_name']) ?> - 
                    <?= number_format($order['total_price'], 2) ?> TL - 
                    <?= htmlspecialchars($order['order_status']) ?> - 
                    <?= htmlspecialchars($order['created_at']) ?>
                </li>
            <?php endforeach; ?>
        </ul>
        <p><a href="müşteriSiparişGeçmişi.php" class="btn">Sipariş Geçmişim</a></p>
    <?php endif; ?>

    <h2>Popüler Restoranlar</h2>
    <ul>
        <?php foreach ($popularRestaurants as $restaurant): ?>
            <li>
                <a href="müşteriRestaurantMenüsü.php?id=<?= $restaurant['id'] ?>">
                    <?= htmlspecialchars($restaurant['name']) ?>
                </a> 
                <a href="müşteriRestaurantMenüsü.php?id=<?= $restaurant['id'] ?>" class="btn">Restoran Detaylarını Gör</a>
            </li>
        <?php endforeach; ?>
    </ul>

    <p><a href="müşteriRestaurant.php" class="btn">Tüm Restoranlar</a></p>
    <p><a href="müşteriYemekArama.php" class="btn">Yemek Siparişi Ver</a></p>
    <p><a href="müşteriSepet.php" class="btn">Sepetim</a></p>
    <p><a href="müşteriProfili.php" class="btn">Profilim</a></p>
    <p><a href="çıkış.php" class="btn">Çıkış Yap</a></p>
</div>
</div>
</body>
</html>

