<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireRole('company');


$userId = $_SESSION['user_id'];
$companyInfo = getCompanyInfoByUserId($pdo, $userId);


$restaurants = getRestaurantsByCompanyId($pdo, $companyInfo['id']);


$orders = getOrdersByCompanyId($pdo, $companyInfo['id']);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Firma Kontrol Paneli</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app">
<div class="container">
    <h1>Hoş geldiniz, <?= htmlspecialchars($companyInfo['name']) ?></h1>
    
    <h2>Hızlı Erişim</h2>
    
    <a href="şirketRestaurantlar.php" class="btn">Restoranlarım</a>
    <a href="şirketYemekler.php" class="btn">Yemekler</a>
    <a href="şirketSiparişler.php" class="btn">Siparişler</a>
    <a href="şirketKuponları.php" class="btn">Kuponlar</a>

    <p><a href="çıkış.php" class="btn">Çıkış Yap</a></p>
</div>
</div>
</body>
</html>