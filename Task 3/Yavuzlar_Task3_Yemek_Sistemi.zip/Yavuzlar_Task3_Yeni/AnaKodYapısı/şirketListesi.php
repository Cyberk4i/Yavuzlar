<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireAdmin();

$filter = $_GET['filter'] ?? 'all';
$validFilters = ['all', 'active', 'deleted'];
if (!in_array($filter, $validFilters)) {
    $filter = 'all';
}

$companies = getCompanies($pdo, $filter);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Firma Listesi</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app">
<div class="container">
    <h1>Firma Listesi</h1>
    
    <form method="GET">
        <select name="filter" class="options">
            <option value="all" <?= $filter == 'all' ? 'selected' : '' ?>>Tümü</option>
            <option value="active" <?= $filter == 'active' ? 'selected' : '' ?>>Aktif</option>
            <option value="deleted" <?= $filter == 'deleted' ? 'selected' : '' ?>>Silinmiş</option>
        </select>
        <input type="submit" value="Filtrele" class="btn">
    </form>
    
    <table>
        <tr>
            <th>ID</th>
            <th>Firma Adı</th>
            <th>Açıklama</th>
            <th>Sahibi</th>
            <th>Durum</th>
            <th>İşlemler</th>
        </tr>
        <?php if (count($companies) > 0): ?>
            <?php foreach ($companies as $company): ?>
            <tr>
                <td><?= htmlspecialchars($company['id']) ?></td>
                <td><?= htmlspecialchars($company['name']) ?></td>
                <td><?= htmlspecialchars($company['description']) ?></td>
                <td><?= htmlspecialchars($company['owner_name'] . ' ' . $company['owner_surname']) ?></td>
                <td><?= $company['deleted_at'] ? 'Silinmiş' : 'Aktif' ?></td>
                <td>
                    <?php if (!$company['deleted_at']): ?>
                        <a href="şirketDüzenleme.php?id=<?= $company['id'] ?>" class="btn">Düzenle</a>
                        <a href="şirketSilme.php?id=<?= $company['id'] ?>" class="btn" onclick="return confirm('Bu firmayı silmek istediğinize emin misiniz?');">Sil</a>
                        <br><br><br><a href="adminSirketveYemek.php?id=<?= $company['id'] ?>" class="btn">Yemekleri Görüntüle</a>
                    <?php else: ?>
                        <a href="şirketGeriYükleme.php?id=<?= $company['id'] ?>" class="btn">Geri Yükle</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="6" style="text-align:center;">Hiç firma bulunamadı.</td>
            </tr>
        <?php endif; ?>
    </table>
    <p><a href="kullanıcıEkle.php" class="btn">Yeni Firma Ekle</a></p>
    <p><a href="admin.php" class="btn">Admin Paneline Dön</a></p>
</div>
</div>
</body>
</html>

