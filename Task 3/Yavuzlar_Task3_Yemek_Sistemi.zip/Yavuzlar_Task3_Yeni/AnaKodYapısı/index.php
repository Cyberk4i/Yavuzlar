<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

if (!isAdminUserExists($pdo)) {
    createDefaultAdminUser($pdo);
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yemek Zinciri Yönetim Sistemi</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="app">
        <div class="container">
            <h1>Yemek Yönetim Sistemi</h1>
            <?php if (isLoggedIn()): ?>
                <p>Hoşgeldin, <?= htmlspecialchars($_SESSION['user_name']) ?>!</p>
                <?php if (isAdmin()): ?>
                    <p><a href="admin.php" class="button">Admin Paneli</a></p>
                <?php elseif (isCompany()): ?>
                    <p><a href="şirketDashboard.php" class="button">Firma Paneli</a></p>
                <?php else: ?>
                    <p><a href="müşteriDashboard.php" class="button">Müşteri Paneli</a></p>
                <?php endif; ?>
                <p><a href="çıkış.php" class="button">Çıkış Yap</a></p>
            <?php else: ?>
                <p><a href="giriş.php" class="button">Giriş Yap</a></p>
                <p><a href="kayıt.php" class="button">Kaydol</a></p>

            <?php endif; ?>
        </div>
    </div>
</body>
</html>


