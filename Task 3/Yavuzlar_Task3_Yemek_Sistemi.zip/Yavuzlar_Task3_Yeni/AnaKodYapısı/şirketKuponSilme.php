<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireRole('company');

$couponId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($couponId > 0) {
    if (deleteCoupon($pdo, $couponId)) {
        $_SESSION['success_message'] = "Kupon başarıyla silindi.";
    } else {
        $_SESSION['error_message'] = "Kupon silinirken bir hata oluştu.";
    }
} else {
    $_SESSION['error_message'] = "Geçersiz kupon ID'si.";
}

header("Location: şirketKuponları.php");
exit();
?>
