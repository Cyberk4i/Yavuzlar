<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireRole('company');

$userId = $_SESSION['user_id'];
$companyInfo = getCompanyInfoByUserId($pdo, $userId);

$search = trim($_GET['search'] ?? '');
$minPrice = trim($_GET['min_price'] ?? '');
$maxPrice = trim($_GET['max_price'] ?? '');

$restaurants = getRestaurantsByCompanyId($pdo, $companyInfo['id']);

$selectedRestaurantId = $_GET['restaurant_id'] ?? '';

$foods = getFoodsByCompanyIdWithDeleted($pdo, $companyInfo['id'], $selectedRestaurantId, $search, $minPrice, $maxPrice);

$restaurantNames = [];
foreach ($restaurants as $restaurant) {
    $restaurantNames[$restaurant['id']] = $restaurant['name'];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yemek Yönetimi</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app">
<div class="container">
    <h1>Yemek Yönetimi</h1>

    <form method="GET" action="">
        <select name="restaurant_id" class="options">
            <option value="">Tüm Restoranlar</option>
            <?php foreach ($restaurants as $restaurant): ?>
                <option value="<?= $restaurant['id'] ?>" <?= $restaurant['id'] == $selectedRestaurantId ? 'selected' : '' ?>>
                    <?= htmlspecialchars($restaurant['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <input type="text" name="search" placeholder="Yemek Adı" value="<?= htmlspecialchars($search) ?>">
        <input type="number" name="min_price" placeholder="Min Fiyat" value="<?= htmlspecialchars($minPrice) ?>" step="0.01">
        <input type="number" name="max_price" placeholder="Max Fiyat" value="<?= htmlspecialchars($maxPrice) ?>" step="0.01">
        <button type="submit" class="btn">Ara</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>Yemek Adı</th>
                <th>Restoran</th>
                <th>Açıklama</th>
                <th>Fiyat</th>
                <th>İndirim</th>
                <th>Durum</th>
                <th>İşlemler</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($foods) > 0): ?>
                <?php foreach ($foods as $food): ?>
                    <tr>
                        <td><?= htmlspecialchars($food['name']) ?></td>
                        <td><?= htmlspecialchars($restaurantNames[$food['restaurant_id']] ?? 'Bilinmeyen Restoran') ?></td>
                        <td><?= htmlspecialchars($food['description']) ?></td>
                        <td><?= number_format($food['price'], 2) ?> TL</td>
                        <td><?= number_format($food['discount'], 2) ?>%</td>
                        <td><?= $food['deleted_at'] ? 'Silinmiş' : 'Aktif' ?></td>
                        <td>
                            <?php if (!$food['deleted_at']): ?>
                                <a href="şirketYemekDüzenleme.php?id=<?= $food['id'] ?>" class="btn">Düzenle</a><br><br>
                                <a href="şirketYemekSilme.php?id=<?= $food['id'] ?>" class="btn" onclick="return confirm('Bu yemeği silmek istediğinizden emin misiniz?')">Sil</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" style="text-align:center;">Hiç yemek bulunamadı.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <p><a href="şirketYemekEkle.php" class="btn">Yeni Yemek Ekle</a></p>
    <p><a href="şirketDashboard.php" class="btn">Firma Paneline Dön</a></p>
</div>
</div>
</body>
</html>
