<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireAdmin();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Paneli</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app">
<div class="container">
    <h1>Admin Paneli</h1>
    <p><a href="kullanıcıListesi.php" class="btn">Tüm Kullanıcıları Listele</a></p>
    <p><a href="kullanıcıEkle.php" class="btn">Kullanıcı Ekle</a></p>
    
    <h2>Müşteri Yönetimi</h2>
    <p><a href="müşteriListesi.php" class="btn">Müşteri Listesi</a></p>
    <p><a href="müşteriArama.php" class="btn">Müşteri Arama</a></p>
    <p><a href="yorumListesi.php" class="btn">Müşteri Yorumları</a></p>
    
    <h2>Firma Yönetimi</h2>
    <p><a href="şirketListesi.php" class="btn">Firma Listesi</a></p>
    <p><a href="şirketArama.php" class="btn">Firma Arama</a></p>
    
    <h2>Kupon Yönetimi</h2>
    <p><a href="kuponListele.php" class="btn">Kupon Listesi</a></p>
    <p><a href="kuponEkleme.php" class="btn">Kupon Ekle</a></p>
    
    <hr>
    <p><a href="veritabanıSıfırlama.php" class="btn">Veritabanı Sıfırlama</a></p>
    <p><a href="index.php" class="btn">Ana Sayfa</a></p>
    <p><a href="çıkış.php" class="btn">Çıkış Yap</a></p>
    
</div>
</div>
</body>
</html>


