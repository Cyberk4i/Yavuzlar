<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireRole('company');

$userId = $_SESSION['user_id'];
$companyInfo = getCompanyInfoByUserId($pdo, $userId);

$restaurantId = $_GET['id'] ?? 0;
$restaurant = getRestaurantById($pdo, $restaurantId);

if (!$restaurant || $restaurant['company_id'] !== $companyInfo['id']) {
    $_SESSION['error_message'] = "Geçersiz restoran.";
    header("Location: şirketRestaurantlar.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $description = $_POST['description'] ?? '';
    $image = $_FILES['image'] ?? null;

    $error = '';
    if (empty($name)) {
        $error = "Restoran adı boş olamaz.";
    }

    if ($image && $image['error'] == 0) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (!in_array($image['type'], $allowedTypes)) {
            $error = "Yalnızca JPEG, PNG veya GIF resimleri yükleyebilirsiniz.";
        } elseif ($image['size'] > 2 * 1024 * 1024) {
            $error = "Resim boyutu 2 MB'dan büyük olamaz.";
        }
    }

    if (empty($error)) {
        try {
            $result = updateRestaurant($pdo, $restaurantId, $name, $description, $image);
            if ($result) {
                $_SESSION['success_message'] = "Restoran başarıyla güncellendi.";
                header("Location: şirketRestaurantlar.php");
                exit();
            } else {
                $error = "Restoran güncellenirken bir hata oluştu.";
            }
        } catch (Exception $e) {
            $error = "Hata: " . $e->getMessage();
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restoran Düzenle</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app">
<div class="container">
    <h1>Restoran Düzenle</h1>
    
    <?php if (isset($error)): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>
    
    <form method="POST" enctype="multipart/form-data">
        <label for="name">Restoran Adı:</label>
        <input type="text" id="name" name="name" value="<?= htmlspecialchars($restaurant['name']) ?>" required>
        
        <label for="description">Açıklama:</label>
        <textarea id="description" name="description"><?= htmlspecialchars($restaurant['description']) ?></textarea>
        
        <label for="image">Yeni Restoran Resmi:</label>
        <input type="file" id="image" name="image" accept="image/*">
        
        <?php if ($restaurant['image_path']): ?>
            <p>Mevcut Resim:</p>
            <img src="<?= htmlspecialchars($restaurant['image_path']) ?>" alt="Restoran Resmi" style="max-width: 200px;">
        <?php endif; ?>
        
        <button type="submit" class="btn">Restoran Güncelle</button>
    </form>
    
    <p><a href="şirketRestaurantlar.php" class="btn">Restoranlarıma Dön</a></p>
</div>
</div>
</body>
</html>
