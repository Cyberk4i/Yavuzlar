CREATE DATABASE IF NOT EXISTS yemek_sistemi;
USE yemek_sistemi;

CREATE TABLE IF NOT EXISTS company (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  logo_path VARCHAR(255) DEFAULT NULL,
  deleted_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS users (
  id INT NOT NULL AUTO_INCREMENT,
  company_id INT DEFAULT NULL,
  role VARCHAR(50) NOT NULL,
  name VARCHAR(100) NOT NULL,
  surname VARCHAR(100) NOT NULL,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(255) NOT NULL,
  balance DECIMAL(10,2) DEFAULT '5000.00',
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP NULL DEFAULT NULL,
  image_path VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY username (username),
  KEY company_id (company_id),
  CONSTRAINT users_ibfk_1 FOREIGN KEY (company_id) REFERENCES company (id)
);



CREATE TABLE IF NOT EXISTS restaurant (
  id INT NOT NULL AUTO_INCREMENT,
  company_id INT DEFAULT NULL,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  image_path VARCHAR(255),
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY company_id (company_id),
  CONSTRAINT restaurant_ibfk_1 FOREIGN KEY (company_id) REFERENCES company (id)
);

CREATE TABLE IF NOT EXISTS comments (
  id INT NOT NULL AUTO_INCREMENT,
  user_id INT NOT NULL,
  restaurant_id INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  score INT NOT NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY user_id (user_id),
  KEY restaurant_id (restaurant_id),
  CONSTRAINT comments_ibfk_1 FOREIGN KEY (user_id) REFERENCES users (id),
  CONSTRAINT comments_ibfk_2 FOREIGN KEY (restaurant_id) REFERENCES restaurant (id)
);



CREATE TABLE IF NOT EXISTS coupon (
  id INT NOT NULL AUTO_INCREMENT,
  restaurant_id INT DEFAULT NULL,
  name VARCHAR(100) NOT NULL,
  discount DECIMAL(5,2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY restaurant_id (restaurant_id),
  CONSTRAINT coupon_ibfk_1 FOREIGN KEY (restaurant_id) REFERENCES restaurant (id)
);



CREATE TABLE IF NOT EXISTS food (
  id INT NOT NULL AUTO_INCREMENT,
  restaurant_id INT NOT NULL,
  name VARCHAR(100) NOT NULL,
  description TEXT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  discount DECIMAL(5, 2) DEFAULT 0,
  image_path VARCHAR(255),
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP NULL,
  PRIMARY KEY (id),
  KEY restaurant_id (restaurant_id),
  CONSTRAINT food_ibfk_1 FOREIGN KEY (restaurant_id) REFERENCES restaurant (id)
);

CREATE TABLE IF NOT EXISTS basket (
  id INT NOT NULL AUTO_INCREMENT,
  user_id INT NOT NULL,
  food_id INT NOT NULL,
  note TEXT,
  quantity INT NOT NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY user_id (user_id),
  KEY food_id (food_id),
  CONSTRAINT basket_ibfk_1 FOREIGN KEY (user_id) REFERENCES users (id),
  CONSTRAINT basket_ibfk_2 FOREIGN KEY (food_id) REFERENCES food (id)
);

CREATE TABLE IF NOT EXISTS `order` (
  id INT NOT NULL AUTO_INCREMENT,
  user_id INT NOT NULL,
  restaurant_id INT NOT NULL,
  total_price DECIMAL(10,2) NOT NULL,
  order_status VARCHAR(50) NOT NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY user_id (user_id),
  KEY restaurant_id (restaurant_id),
  CONSTRAINT orders_ibfk_1 FOREIGN KEY (user_id) REFERENCES users (id),
  CONSTRAINT orders_ibfk_2 FOREIGN KEY (restaurant_id) REFERENCES restaurant (id)
);

CREATE TABLE IF NOT EXISTS order_items (
  id INT NOT NULL AUTO_INCREMENT,
  order_id INT NOT NULL,
  food_id INT NOT NULL,
  quantity INT NOT NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  price DECIMAL(10, 2) NOT NULL,
  PRIMARY KEY (id),
  KEY order_id (order_id),
  KEY food_id (food_id),
  CONSTRAINT order_details_ibfk_1 FOREIGN KEY (order_id) REFERENCES `order` (id),
  CONSTRAINT order_details_ibfk_2 FOREIGN KEY (food_id) REFERENCES food (id)
);


