<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireRole('customer');

$userId = $_SESSION['user_id'];
$cartItems = getCartItems($pdo, $userId);

$couponCode = $_SESSION['applied_coupon'] ?? '';
$discount = 0;

if ($couponCode) {
    $coupon = getCouponByCode($pdo, $couponCode);

    if ($coupon) {
        $validCoupon = false;

        foreach ($cartItems as $item) {
            if ($coupon['restaurant_id'] == $item['restaurant_id']) {
                $validCoupon = true;
                break;
            }
        }

        if ($validCoupon) {
            $discount = $coupon['discount'];
        } else {
            $_SESSION['error_message'] = "Bu kupon kodu sepetinizdeki ürünler için geçerli değil.";
            unset($_SESSION['applied_coupon']);
            header("Location: müşteriSepet.php");
            exit();
        }
    } else {
        $_SESSION['error_message'] = "Geçersiz kupon kodu.";
        unset($_SESSION['applied_coupon']);
        header("Location: müşteriSepet.php");
        exit();
    }
}

$total = calculateCartTotal($cartItems, $discount);

$restaurantId = $cartItems[0]['restaurant_id'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$restaurantId) {
        $_SESSION['error_message'] = "Restoran ID'si bulunamadı.";
        header("Location: müşteriSepet.php");
        exit();
    }

    $pdo->beginTransaction();

    try {
        $orderId = createOrder($pdo, $userId, $restaurantId, $total);

        foreach ($cartItems as $item) {
            if (!isset($item['food_id'])) {
                throw new Exception("Sepetteki bir öğenin yemek ID'si tanımlı değil.");
            }
            addOrderItem($pdo, $orderId, $item['food_id'], $item['quantity'], $item['price']);
        }

        updateUserBalance($pdo, $userId, -$total);

        clearCart($pdo, $userId);

        $pdo->commit();
        $_SESSION['success_message'] = "Siparişiniz başarıyla oluşturuldu.";
        header("Location: müşteriSiparişGeçmişi.php");
        exit();
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error_message'] = "Sipariş oluşturulurken bir hata oluştu: " . $e->getMessage();
        header("Location: müşteriSepet.php");
        exit();
    }
}
?>
