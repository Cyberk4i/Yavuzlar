<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireRole('customer');

$userId = $_SESSION['user_id'];
$cartItems = getCartItems($pdo, $userId);
$restaurantId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$coupons = getRestaurantCoupons($pdo, $restaurantId);

$couponCode = isset($_SESSION['applied_coupon']) ? $_SESSION['applied_coupon'] : '';
$discount = 0;

if ($couponCode) {
    $coupon = getCouponByCode($pdo, $couponCode);

    if ($coupon) {
        $validCoupon = false;

        foreach ($cartItems as $item) {
            if ($coupon['restaurant_id'] == $item['restaurant_id']) {
                $validCoupon = true;
                break;
            }
        }

        if ($validCoupon) {
            $discount = $coupon['discount'];
        } else {
            $_SESSION['error_message'] = "Bu kupon kodu sepetinizdeki ürünler için geçerli değil.";
            unset($_SESSION['applied_coupon']);
        }
    } else {
        $_SESSION['error_message'] = "Geçersiz kupon kodu.";
        unset($_SESSION['applied_coupon']);
    }
}

$total = calculateCartTotal($cartItems);

if ($discount > 0) {
    $totalDiscount = ($total * $discount) / 100;
    $total -= $totalDiscount;
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sepetim</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app">
<div class="container">
    <h1>Sepetim</h1>

    <?php if (isset($_SESSION['success_message'])): ?>
        <p class="success"><?= htmlspecialchars($_SESSION['success_message']) ?></p>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['error_message'])): ?>
        <p class="error"><?= htmlspecialchars($_SESSION['error_message']) ?></p>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>

    <?php if (!empty($coupons)): ?>
        <div class="coupons">
            <h2>Tüm Restoranlarda Geçerli Kuponlar</h2>
            <ul>
                <?php foreach ($coupons as $coupon): ?>
                    <li><?= htmlspecialchars($coupon['name']) ?> - %<?= $coupon['discount'] ?> indirim</li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if (empty($cartItems)): ?>
        <p>Sepetiniz boş. Lütfen ürün ekleyin.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Yemek</th>
                    <th>Fiyat</th>
                    <th>İndirimli Fiyat</th>
                    <th>Miktar</th>
                    <th>Toplam</th>
                    <th>Not</th>
                    <th>İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cartItems as $item): ?>
                    <tr>
                        <td><?= htmlspecialchars($item['food_name']) ?></td>
                        <td><?= number_format($item['price'], 2) ?> TL</td>
                        <td><?= number_format($item['price'] * (1 - $item['discount'] / 100), 2) ?> TL</td>
                        <td>
                            <form action="sepetGüncelle.php" method="POST">
                                <input type="hidden" name="basket_id" value="<?= $item['id'] ?>">
                                <input type="number" name="quantity" value="<?= $item['quantity'] ?>" min="1" max="10">
                                <button type="submit" class="btn">Güncelle</button>
                            </form>
                        </td>
                        <td><?= number_format($item['price'] * $item['quantity'] * (1 - $item['discount'] / 100), 2) ?> TL</td>
                        <td>
                            <form action="sepetNotuGüncelle.php" method="POST">
                                <input type="hidden" name="basket_id" value="<?= $item['id'] ?>">
                                <input type="text" name="note" value="<?= htmlspecialchars($item['note']) ?>">
                                <button type="submit" class="btn">Not Güncelle</button>
                            </form>
                        </td>
                        <td>
                            <form action="sepetÜrünKaldırma.php" method="POST">
                                <input type="hidden" name="basket_id" value="<?= $item['id'] ?>">
                                <button type="submit" class="btn">Kaldır</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <?php if ($couponCode): ?>
            <p>Uygulanan Kupon: <?= htmlspecialchars($couponCode) ?></p>
            <p>İndirim: %<?= $discount ?></p>
            <form action="kuponKaldır.php" method="POST">
                <button type="submit" class="btn">Kuponu Kaldır</button>
            </form>
        <?php else: ?>
            <form action="kuponUygula.php" method="POST">
                <label for="coupon_code">Kupon Kodu:</label>
                <input type="text" id="coupon_code" name="coupon_code" required>
                <button type="submit" class="btn">Kuponu Uygula</button>
            </form>
        <?php endif; ?>

        <p>Toplam: <?= number_format($total, 2) ?> TL</p>

        <form action="siparişVer.php" method="POST">
            <button type="submit" class="btn">Sipariş Ver</button>
        </form>
    <?php endif; ?>

    <p><a href="müşteriRestaurant.php" class="btn">Alışverişe Devam Et</a></p>
    <p><a href="müşteriDashboard.php" class="btn">Ana Sayfaya Dön</a></p>
</div>
</div>
</body>
</html>
