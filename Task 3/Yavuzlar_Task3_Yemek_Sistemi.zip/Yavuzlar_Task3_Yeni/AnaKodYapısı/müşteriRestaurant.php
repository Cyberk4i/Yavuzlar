<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireRole('customer');

$userId = $_SESSION['user_id'];

$search = filter_input(INPUT_GET, 'search', FILTER_SANITIZE_STRING) ?? '';

$restaurants = searchRestaurants($pdo, $search);

?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restoranlar</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app">
<div class="container">
    <h1>Restoranlar</h1>

    <form method="GET" action="">
        <input type="text" name="search" placeholder="Restoran Ara" value="<?= htmlspecialchars($search) ?>">
        <button type="submit" class="btn">Ara</button>
    </form>

    <?php if (empty($restaurants)): ?>
        <p>Restoran bulunamadı.</p>
    <?php else: ?>
        <div class="restaurant-list">
            <?php foreach ($restaurants as $restaurant): ?>
                <div class="restaurant-item">
                    <h2><?= htmlspecialchars($restaurant['name']) ?></h2>
                    <p><?= htmlspecialchars($restaurant['description']) ?></p>
                    <?php if (!empty($restaurant['image_path']) && file_exists($restaurant['image_path'])): ?>
                        <img src="<?= htmlspecialchars($restaurant['image_path']) ?>" alt="<?= htmlspecialchars($restaurant['name']) ?>" style="max-width: 200px;">
                    <?php endif; ?>
                    <p>Ortalama Puan: <?= number_format($restaurant['average_score'], 1) ?>/10</p>
                    <a href="müşteriRestaurantMenüsü.php?id=<?= $restaurant['id'] ?>" class="btn">Menüyü Gör</a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <p><a href="tümRestaurentYorumları.php" class="btn">Restoran Yorumlarına Bak</a></p>
    <p><a href="müşteriDashboard.php" class="btn">Ana Sayfaya Dön</a></p>
</div>
</div>
</body>
</html>


