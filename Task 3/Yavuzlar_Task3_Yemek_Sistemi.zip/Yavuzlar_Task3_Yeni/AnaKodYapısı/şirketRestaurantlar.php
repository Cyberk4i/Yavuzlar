<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireRole('company');

$userId = $_SESSION['user_id'];
$companyInfo = getCompanyInfoByUserId($pdo, $userId);

$restaurants = getRestaurantsByCompanyId($pdo, $companyInfo['id']);

$success_message = $_SESSION['success_message'] ?? null;
$error_message = $_SESSION['error_message'] ?? null;
unset($_SESSION['success_message'], $_SESSION['error_message']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restoranlarım</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app">
<div class="container">
    <h1>Restoranlarım</h1>
    
    <?php if ($success_message): ?>
        <p class="success"><?= htmlspecialchars($success_message) ?></p>
    <?php endif; ?>
    
    <?php if ($error_message): ?>
        <p class="error"><?= htmlspecialchars($error_message) ?></p>
    <?php endif; ?>
    
    <?php if (empty($restaurants)): ?>
        <p>Henüz restoran eklenmemiş.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Restoran Adı</th>
                    <th>Açıklama</th>
                    <th>İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($restaurants as $restaurant): ?>
                    <tr>
                        <td><?= htmlspecialchars($restaurant['name']) ?></td>
                        <td><?= htmlspecialchars($restaurant['description']) ?></td>
                        <td>
                            <a href="şirketRestaurantDüzenleme.php?id=<?= $restaurant['id'] ?>" class="btn">Düzenle</a>
                            <a href="şirketRestaurantSilme.php?id=<?= $restaurant['id'] ?>" class="btn" onclick="return confirm('Bu restoranı silmek istediğinizden emin misiniz?')">Sil</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
    
    <p><a href="şirketRestaurantEkle.php" class="btn">Yeni Restoran Ekle</a></p>
    <p><a href="şirketDashboard.php" class="btn">Firma Paneline Dön</a></p>
</div>
</div>
</body>
</html>

