<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireAdmin();

$couponId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($couponId) {
    if (deleteCoupon($pdo, $couponId)) {
        $_SESSION['success_message'] = "Kupon başarıyla silindi.";
    } else {
        $_SESSION['error_message'] = "Kupon silinirken bir hata oluştu.";
    }
} else {
    $_SESSION['error_message'] = "Geçersiz kupon ID.";
}

header("Location: kuponListele.php");
exit();
