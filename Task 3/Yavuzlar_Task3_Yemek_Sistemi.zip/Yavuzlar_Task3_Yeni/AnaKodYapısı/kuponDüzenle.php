<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireAdmin();

$couponId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$coupon = getCouponById($pdo, $couponId);
$restaurants = getRestaurants($pdo);

if (!$coupon) {
    $_SESSION['error_message'] = "Kupon bulunamadı.";
    header("Location: kuponListele.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $discount = filter_input(INPUT_POST, 'discount', FILTER_VALIDATE_INT);
    $restaurantId = !empty($_POST['restaurant_id']) ? intval($_POST['restaurant_id']) : null;

    if ($discount < 0 || $discount > 100) {
        $error = "İndirim yüzdesi 0 ile 100 arasında olmalıdır.";
    } elseif (updateCoupon($pdo, $couponId, $name, $discount, $restaurantId)) {
        $_SESSION['success_message'] = "Kupon başarıyla güncellendi.";
        header("Location: kuponListele.php");
        exit();
    } else {
        $error = "Kupon güncellenirken bir hata oluştu.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kupon Düzenle</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app">
<div class="container">
    <h1>Kupon Düzenle</h1>
    <?php if (isset($error)): ?>
        <p style="color: red;"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>
    <form method="POST">
        <input type="text" name="name" value="<?= htmlspecialchars($coupon['name']) ?>" placeholder="Kupon Adı" required><br>
        <input type="number" name="discount" value="<?= htmlspecialchars($coupon['discount']) ?>" placeholder="İndirim Yüzdesi" min="0" max="100" required><br>
        <select name="restaurant_id" class="options">
            <option value="">Tüm Restoranlar</option>
            <?php foreach ($restaurants as $restaurant): ?>
                <option value="<?= $restaurant['id'] ?>" <?= $coupon['restaurant_id'] == $restaurant['id'] ? 'selected' : '' ?>><?= htmlspecialchars($restaurant['name']) ?></option>
            <?php endforeach; ?>
        </select><br>
        <input type="submit" value="Kuponu Güncelle" class="btn">
    </form>
    <p><a href="kuponListele.php" class="btn">Kupon Listesine Dön</a></p>
</div>
</div>
</body>
</html>

