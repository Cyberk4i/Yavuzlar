<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireAdmin();

$customerId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if ($customerId === false || $customerId <= 0) {
    $_SESSION['error_message'] = "Geçersiz müşteri kimliği.";
    header("Location: müşteriListesi.php");
    exit();
}

if (banCustomer($pdo, $customerId)) {
    $_SESSION['success_message'] = "Müşteri başarıyla banlandı.";
} else {
    $_SESSION['error_message'] = "Müşteri banlanırken bir hata oluştu.";
}

header("Location: müşteriListesi.php");
exit();
