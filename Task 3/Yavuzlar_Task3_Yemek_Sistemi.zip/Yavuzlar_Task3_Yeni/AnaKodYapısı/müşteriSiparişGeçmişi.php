<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireRole('customer');

$userId = $_SESSION['user_id'];
$pastOrders = getPastOrdersByUserId($pdo, $userId);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sipariş Geçmişim</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app">
<div class="container">
    <h1>Sipariş Geçmişim</h1>

    <?php if (empty($pastOrders)): ?>
        <p>Henüz sipariş vermemişsiniz.</p>
    <?php else: ?>
        <?php foreach ($pastOrders as $order): ?>
            <div class="order">
                <h2>Sipariş #<?= htmlspecialchars($order['id']) ?></h2>
                <p>Tarih: <?= (new DateTime($order['created_at']))->format('d.m.Y H:i') ?></p>
                <p>Durum: <?= htmlspecialchars($order['order_status']) ?></p>
                <p>Toplam: <?= number_format($order['total_price'], 2) ?> TL</p>
                <h3>Sipariş Detayları:</h3>
                <ul>
                    <?php foreach ($order['items'] as $item): ?>
                        <li>
                            <?= htmlspecialchars($item['food_name']) ?> - 
                            <?= intval($item['quantity']) ?> adet - 
                            <?= number_format($item['price'], 2) ?> TL
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <p><a href="müşteriDashboard.php" class="btn">Ana Sayfaya Dön</a></p>
</div>
</div>
</body>
</html>