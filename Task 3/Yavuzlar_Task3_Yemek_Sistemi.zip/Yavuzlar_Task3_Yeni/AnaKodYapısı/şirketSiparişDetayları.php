<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';
requireLogin();
requireRole('company');

$orderId = $_GET['id'] ?? 0;
$userId = $_SESSION['user_id'];
$companyInfo = getCompanyInfoByUserId($pdo, $userId);
$orderDetails = getOrderDetails($pdo, $orderId, $companyInfo['id']);

if (!$orderDetails) {
    $_SESSION['error_message'] = "Geçersiz sipariş veya yetkiniz yok.";
    header("Location: şirketSiparişler.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sipariş Detayları</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app">
<div class="container">
    <h1>Sipariş Detayları</h1>

    <h2>Sipariş Bilgileri</h2>
    <p>Sipariş ID: <?= htmlspecialchars($orderDetails['id']) ?></p>
    <p>Müşteri: <?= htmlspecialchars($orderDetails['customer_name']) ?></p>
    <p>Restoran: <?= htmlspecialchars($orderDetails['restaurant_name']) ?></p>
    <p>Toplam Fiyat: <?= number_format($orderDetails['total_price'], 2) ?> TL</p>
    <p>Durum: <?= htmlspecialchars($orderDetails['order_status']) ?></p>
    <p>Tarih: <?= date('d/m/Y H:i:s', strtotime($orderDetails['created_at'])) ?></p>

    <h2>Sipariş Öğeleri</h2>
    <?php if (!empty($orderDetails['items'])): ?>
        <table>
            <thead>
                <tr>
                    <th>Yemek Adı</th>
                    <th>Adet</th>
                    <th>Birim Fiyat</th>
                    <th>Toplam Fiyat</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orderDetails['items'] as $item): ?>
                    <tr>
                        <td><?= htmlspecialchars($item['food_name']) ?></td>
                        <td><?= htmlspecialchars($item['quantity']) ?></td>
                        <td><?= number_format($item['price'], 2) ?> TL</td>
                        <td><?= number_format($item['quantity'] * $item['price'], 2) ?> TL</td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Bu siparişin öğesi bulunmamaktadır.</p>
    <?php endif; ?>

    <p><a href="şirketSiparişler.php" class="btn">Siparişlere Dön</a></p>
</div>
</div>
</body>
</html>

