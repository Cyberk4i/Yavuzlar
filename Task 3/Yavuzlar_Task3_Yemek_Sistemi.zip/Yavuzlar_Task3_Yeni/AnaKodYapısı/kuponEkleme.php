<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

requireLogin();
requireAdmin();

$restaurants = getRestaurants($pdo);
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']) ?? '';
    $discount = filter_var($_POST['discount'], FILTER_VALIDATE_INT) ?? '';
    $restaurantId = !empty($_POST['restaurant_id']) ? $_POST['restaurant_id'] : null;

    if ($discount === false || $discount < 0 || $discount > 100) {
        $error = "İndirim yüzdesi geçerli bir değer olmalıdır (0-100 arası).";
    } else {
        if (addCoupon($pdo, $name, $discount, $restaurantId)) {
            $_SESSION['success_message'] = "Kupon başarıyla eklendi.";
            header("Location: kuponListele.php");
            exit();
        } else {
            $error = "Kupon eklenirken bir hata oluştu.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kupon Ekle</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app">
<div class="container">
    <h1>Kupon Ekle</h1>
    
    <?php if (isset($error)): ?>
        <p style="color: red;"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>
    
    <form method="POST">
        <div>
            <input type="text" name="name" placeholder="Kupon Adı" required>
        </div>
        <div>
            <input type="number" name="discount" placeholder="İndirim Yüzdesi" min="0" max="100" required>
        </div>
        <div>
            <select name="restaurant_id" class="options">
                <option value="">Tüm Restoranlar</option>
                <?php foreach ($restaurants as $restaurant): ?>
                    <option value="<?= $restaurant['id'] ?>"><?= htmlspecialchars($restaurant['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <input type="submit" value="Kupon Ekle" class="btn">
        </div>
    </form>
    
    <p><a href="kuponListele.php" class="btn">Kupon Listesine Dön</a></p>
</div>
</div>
</body>
</html>
