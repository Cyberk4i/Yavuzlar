<?php
session_start();
require_once __DIR__ . '/veritabani.php';
require_once __DIR__ . '/fonksiyonlar.php';

if (isLoggedIn()) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = $_POST['name'] ?? '';
    $surname = $_POST['surname'] ?? '';
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    

    if (registerUser($pdo, $name, $surname, $username, $password)) {
        header("Location: giriş.php");
        exit();
    } else {
        $error = "Kullanıcı kaydı sırasında bir hata oluştu.";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kayıt Ol</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app">
    <div class="container">
        <h1>Kaydol</h1>
        <?php if (isset($error)): ?>
            <p style="color: red;"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>
        <form method="POST">
            <input type="text" name="name" placeholder="Ad" required><br>
            <input type="text" name="surname" placeholder="Soyad" required><br>
            <input type="text" name="username" placeholder="Kullanıcı adı" required><br>
            <input type="password" name="password" placeholder="Şifre" required><br>
            <input type="submit" value="Kaydol" class="btn">
        </form>
        <br>
        <p><a href="giriş.php" class="btn">Giriş Yap</a></p>
        <p><a href="index.php" class="btn">Ana Sayfa</a></p>
    </div>
</div>
</body>
</html>


