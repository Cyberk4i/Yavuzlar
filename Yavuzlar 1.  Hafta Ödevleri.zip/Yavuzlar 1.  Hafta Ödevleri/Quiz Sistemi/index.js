if (typeof questionsData === "undefined") {
  

    const questionsData = {
        
        "questions": [
    {"index": 1, "Difficulty": "easy", "Question": "Python'da bir listedeki eleman sayısını bulmak için hangi fonksiyon kullanılır?", "Answer1": "len()", "Answer2": "count()", "Answer3": "size()", "Answer4": "length()", "rightAnswer": 1},
    {"index": 2, "Difficulty": "easy", "Question": "CSS'de yazı tipi boyutu nasıl değiştirilir?", "Answer1": "font-size", "Answer2": "text-size", "Answer3": "font-weight", "Answer4": "text-weight", "rightAnswer": 1},
    {"index": 13, "Difficulty": "easy", "Question": "Bir JavaScript dosyasını HTML sayfasına eklemek için hangi yöntem kullanılır?", "Answer1": "import", "Answer2": "include", "Answer3": "require", "Answer4": "script", "rightAnswer": 4},
    {"index": 4, "Difficulty": "medium", "Question": "JavaScript'te hangi veri tipi yoktur?", "Answer1": "String", "Answer2": "Number", "Answer3": "Boolean", "Answer4": "Character", "rightAnswer": 4},
    {"index": 5, "Difficulty": "hard", "Question": "TCP/IP modelinde hangi katman yoktur?", "Answer1": "Uygulama", "Answer2": "Bağlantı", "Answer3": "Nakil", "Answer4": "Sunum", "rightAnswer": 4},
    {"index": 6, "Difficulty": "easy", "Question": "Python'da hangi fonksiyon ekrana çıktı verir?", "Answer1": "output()", "Answer2": "write()", "Answer3": "print()", "Answer4": "echo()", "rightAnswer": 3},
    {"index": 7, "Difficulty": "medium", "Question": "Bir bilgisayar ağında veri paketlerinin iletilmesi hangi katman tarafından gerçekleştirilir?", "Answer1": "Uygulama katmanı", "Answer2": "Nakil katmanı", "Answer3": "Ağ katmanı", "Answer4": "Veri Bağlantısı katmanı", "rightAnswer": 3},
    {"index": 8, "Difficulty": "medium", "Question": "Hangisi JavaScript döngü yapısıdır?", "Answer1": "if", "Answer2": "for", "Answer3": "while", "Answer4": "switch", "rightAnswer": 2},
    {"index": 9, "Difficulty": "hard", "Question": "MySQL'de veri tabanı oluşturma komutu nedir?", "Answer1": "CREATE DATABASE", "Answer2": "CREATE TABLE", "Answer3": "INSERT INTO", "Answer4": "SELECT", "rightAnswer": 1},
    {"index": 10, "Difficulty": "easy", "Question": "CSS'de yazı rengi nasıl değiştirilir?", "Answer1": "text-color", "Answer2": "font-color", "Answer3": "color", "Answer4": "background-color", "rightAnswer": 3}
  ]
      }
    localStorage.setItem('questions', JSON.stringify(questionsData));
    const storedQuestions = JSON.parse(localStorage.getItem('questions'));
    console.log(storedQuestions);
    }
    
    