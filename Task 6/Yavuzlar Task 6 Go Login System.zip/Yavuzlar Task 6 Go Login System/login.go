package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
	"time"
)

type User struct {
	Username string
	Password string
	Role     string
}

var users = []User{
	{"admin", "admin123", "admin"},
	{"customer", "pass123", "customer"},
}

func logAction(action string) {
	file, err := os.OpenFile("log.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		fmt.Println("Log dosyasına yazılamadı:", err)
		return
	}
	defer file.Close()

	log := fmt.Sprintf("%s: %s\n", time.Now().Format("02.01.2006 15:04:05"), action)

	file.WriteString(log)
}

func login() (User, bool) {
	reader := bufio.NewReader(os.Stdin)

	fmt.Print("Kullanıcı Adı: ")
	username, _ := reader.ReadString('\n')
	username = strings.TrimSpace(username)

	if username == "" {
		fmt.Println("Kullanıcı adı boş bırakılamaz. Lütfen tekrar deneyin.")
		logAction("Kullanıcı adı boş bırakıldı.")
		return login()
	}

	fmt.Print("Şifre: ")
	password, _ := reader.ReadString('\n')
	password = strings.TrimSpace(password)

	for _, user := range users {
		if user.Username == username && user.Password == password {
			logAction(fmt.Sprintf("Başarılı giriş: %s (%s)", username, user.Role))
			return user, true
		}
	}

	fmt.Println("Hatalı kullanıcı adı veya şifre. Lütfen tekrar deneyin.")
	logAction(fmt.Sprintf("Başarısız giriş: %s", username))
	return login()
}

func adminMenu() {
	for {
		fmt.Println("\n==== Admin Menüsü ====")
		fmt.Println("1 - Müşteri Ekle")
		fmt.Println("2 - Müşteri Sil")
		fmt.Println("3 - Log Listele")
		fmt.Println("4 - Çıkış")
		fmt.Print("Seçiminiz: ")

		var choice int
		fmt.Scanln(&choice)

		switch choice {
		case 1:
			addCustomer()
		case 2:
			deleteCustomer()
		case 3:
			listLogs()
		case 4:
			fmt.Println("Çıkış yapılıyor.")
			return
		default:
			fmt.Println("Geçersiz seçim. Lütfen tekrar deneyin.")
		}
	}
}

func customerMenu(user User) {
	for {
		fmt.Println("\n==== Müşteri Menüsü ====")
		fmt.Println("1 - Profil Görüntüleme")
		fmt.Println("2 - Şifre Değiştir")
		fmt.Println("3 - Çıkış")
		fmt.Print("Seçiminiz: ")

		var choice int
		fmt.Scanln(&choice)

		switch choice {
		case 1:
			viewProfile(user)
		case 2:
			user = changePassword(user)
		case 3:
			fmt.Println("Çıkış yapılıyor.")
			return
		default:
			fmt.Println("Geçersiz seçim. Lütfen tekrar deneyin.")
		}
	}
}

func addCustomer() {
	reader := bufio.NewReader(os.Stdin)

	fmt.Print("Yeni Müşteri Kullanıcı Adı: ")
	username, _ := reader.ReadString('\n')
	username = strings.TrimSpace(username)

	if username == "" {
		fmt.Println("Kullanıcı adı boş bırakılamaz. Lütfen tekrar deneyin.")
		logAction("Kullanıcı adı boş bırakıldı.")
		addCustomer()
		return
	}

	fmt.Print("Yeni Müşteri Şifresi: ")
	password, _ := reader.ReadString('\n')
	password = strings.TrimSpace(password)

	users = append(users, User{Username: username, Password: password, Role: "customer"})
	logAction(fmt.Sprintf("Müşteri eklendi: %s", username))
	fmt.Println("Müşteri başarıyla eklendi.")
}

func deleteCustomer() {
	reader := bufio.NewReader(os.Stdin)

	fmt.Print("Silinecek Müşteri Kullanıcı Adı: ")
	username, _ := reader.ReadString('\n')
	username = strings.TrimSpace(username)

	if username == "" {
		fmt.Println("Kullanıcı adı boş bırakılamaz. Lütfen tekrar deneyin.")
		logAction("Kullanıcı adı boş bırakıldı.")
		deleteCustomer()
		return
	}

	for i, user := range users {
		if user.Username == username && user.Role == "customer" {
			users = append(users[:i], users[i+1:]...)
			logAction(fmt.Sprintf("Müşteri silindi: %s", username))
			fmt.Println("Müşteri başarıyla silindi.")
			return
		}
	}

	fmt.Println("Müşteri bulunamadı.")
}

func listLogs() {
	file, err := os.Open("log.txt")
	if err != nil {
		fmt.Println("Log dosyası açılamadı:", err)
		return
	}
	defer file.Close()

	fmt.Println("\n==== Loglar ====")
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		fmt.Println(scanner.Text())
	}

	if err := scanner.Err(); err != nil {
		fmt.Println("Log okuma hatası:", err)
	}
}

func viewProfile(user User) {
	fmt.Printf("\n==== Profil Bilgileri ====\n")
	fmt.Printf("Kullanıcı Adı: %s\n", user.Username)
	fmt.Printf("Rol: %s\n", user.Role)
}

func changePassword(user User) User {
	reader := bufio.NewReader(os.Stdin)

	fmt.Print("Yeni Şifre: ")
	newPassword, _ := reader.ReadString('\n')
	newPassword = strings.TrimSpace(newPassword)

	for i, u := range users {
		if u.Username == user.Username {
			users[i].Password = newPassword
			logAction(fmt.Sprintf("Şifre değiştirildi: %s", user.Username))
			fmt.Println("Şifre başarıyla değiştirildi.")
			return users[i]
		}
	}

	fmt.Println("Şifre değiştirilemedi.")
	return user
}

func mainMenu() {
	for {
		fmt.Println("\n==== Hoş Geldiniz ====")
		fmt.Println("Giriş Tipini Seçin:")
		fmt.Println("0 - Admin")
		fmt.Println("1 - Müşteri")
		fmt.Println("2 - Çıkış")
		fmt.Print("Seçiminiz: ")

		var choice int
		fmt.Scanln(&choice)

		switch choice {
		case 0, 1:
			user, success := login()
			if success {
				if choice == 0 && user.Role == "admin" {
					adminMenu()
				} else if choice == 1 && user.Role == "customer" {
					customerMenu(user)
				} else {
					fmt.Println("Yetki hatası: Yanlış kullanıcı türü seçimi.")
				}
			}
		case 2:
			fmt.Println("Çıkış yapılıyor. Hoşça kalın!")
			return
		default:
			fmt.Println("Geçersiz seçim. Lütfen tekrar deneyin.")
		}
	}
}

func main() {
	mainMenu()
}
