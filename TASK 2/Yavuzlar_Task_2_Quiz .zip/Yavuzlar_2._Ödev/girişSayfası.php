<?php
session_start();
include 'quiz_data.php';
include 'quiz_functions.php';

if(!isset($_POST['username']) || !isset($_POST['password'])) {
    header("Location: girişSayfası.php?message=Kullanıcı adı ve şifre boş bırakılamaz!");
    die();
}
else{

    $username = $_POST['username'];
    $password = $_POST['password'];

    $result = Login($username,$password);

    $_SESSION["id"] = $result["id"];
    $_SESSION["isAdmin"] = $result["isAdmin"];
    $_SESSION["username"] = $result["username"];
    
    header("Location:anaSayfa.php");
    exit();

}





