<?php

include 'quiz_data.php';


$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $question = $_POST['question'];
    $answer1 = $_POST['answer1'];
    $answer2 = $_POST['answer2'];
    $answer3 = $_POST['answer3'];
    $answer4 = $_POST['answer4'];
    $rightAnswer = $_POST['rightAnswer'];
    $difficulty = $_POST['difficulty'];

  
    $query = "UPDATE questions SET soru = :question, cevap1 = :answer1, cevap2 = :answer2, cevap3 = :answer3, cevap4 = :answer4, dogru_cevap = :rightAnswer, zorluk = :difficulty WHERE id = :id";
    
    $statement = $pdo->prepare($query);
    $statement->execute([
        ':question' => $question,
        ':answer1' => $answer1,
        ':answer2' => $answer2,
        ':answer3' => $answer3,
        ':answer4' => $answer4,
        ':rightAnswer' => $rightAnswer,
        ':difficulty' => $difficulty,
        ':id' => $id
    ]);

    echo "Soru başarıyla güncellendi!";
    header("Location: soruListele.php");
    exit;
}


$query = "SELECT * FROM questions WHERE id = :id";
$statement = $pdo->prepare($query);
$statement->execute([':id' => $id]);
$question = $statement->fetch(PDO::FETCH_ASSOC);

if (!$question) {
    echo "Soru bulunamadı.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="tr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Soruyu Düzenle</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>

  <div class="editQuestion">
    <h1>Soruyu Düzenle</h1>
    <form method="post" action="">
      <label for="question">Soru:</label><br>
      <input type="text" id="question" name="question" value="<?php echo $question['soru']; ?>" required><br><br>
      
      <label for="answer1">Cevap 1:</label><br>
      <input type="text" id="answer1" name="answer1" value="<?php echo $question['cevap1']; ?>" required><br><br>
      
      <label for="answer2">Cevap 2:</label><br>
      <input type="text" id="answer2" name="answer2" value="<?php echo $question['cevap2']; ?>" required><br><br>
      
      <label for="answer3">Cevap 3:</label><br>
      <input type="text" id="answer3" name="answer3" value="<?php echo $question['cevap3']; ?>" required><br><br>
      
      <label for="answer4">Cevap 4:</label><br>
      <input type="text" id="answer4" name="answer4" value="<?php echo $question['cevap4']; ?>" required><br><br>
      
      <label for="rightAnswer">Doğru Cevap:</label><br>
      <input type="text" id="rightAnswer" name="rightAnswer" value="<?php echo $question['dogru_cevap']; ?>" required><br><br>
      
      <label for="difficulty">Zorluk:</label><br>
      <select name="difficulty" id="difficulty" required>
          <option value="" disabled>Zorluğu Seçiniz</option>
          <option value="easy" <?php echo $question['zorluk'] === 'easy' ? 'selected' : ''; ?>>Kolay</option>
          <option value="normal" <?php echo $question['zorluk'] === 'normal' ? 'selected' : ''; ?>>Normal</option>
          <option value="hard" <?php echo $question['zorluk'] === 'hard' ? 'selected' : ''; ?>>Zor</option>
      </select><br><br>
      
      <input type="submit" class="button3" value="Kaydet">
    </form>
    
    <br>
    <a href="soruListele.php" class="button2">Geri Dön</a>
    <a href="anaSayfa.php" class="button2">Ana Sayfaya Git</a>
  </div>

</body>

</html>
