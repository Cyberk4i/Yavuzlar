<?php
include 'quiz_data.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $soru = $_POST['question'];
    $zorluk = $_POST['difficulty'];
    $cevap1 = $_POST['answer1'];
    $cevap2 = $_POST['answer2'];
    $cevap3 = $_POST['answer3'];
    $cevap4 = $_POST['answer4'];
    $dogru_cevap = $_POST['rightAnswer'];

    $query = "INSERT INTO questions (soru, cevap1, cevap2, cevap3, cevap4, dogru_cevap, zorluk) 
              VALUES (:soru, :cevap1, :cevap2, :cevap3, :cevap4, :dogru_cevap, :zorluk)";
    
    $statement = $pdo->prepare($query);

    $statement->execute([
        ':soru' => $soru,
        ':cevap1' => $cevap1,
        ':cevap2' => $cevap2,
        ':cevap3' => $cevap3,
        ':cevap4' => $cevap4,
        ':dogru_cevap' => $dogru_cevap,
        ':zorluk' => $zorluk
    ]);

    echo "Soru başarıyla kaydedildi!";
    echo '<form action="soruEkle.html" method="get">';
    echo '<button type="submit">Geri Dön</button>';
    echo '</form>';
    exit();
    
} else {
    echo "Kaydedilecek veri yok.";
    echo '<form action="soruEkle.html" method="get">';
    echo '<button type="submit">Geri Dön</button>';
    echo '</form>';
    exit();
}
?>
