<?php
session_start();
include 'quiz_data.php';

if (isset($_POST['score']) && isset($_SESSION['id'])) {
    $score = intval($_POST['score']);
    $user_id = $_SESSION['id'];

    try {
        $pdo = new PDO("sqlite:db/quiz_data.db");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $query = "UPDATE users SET score = :score WHERE id = :id";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':score', $score, PDO::PARAM_INT);
        $stmt->bindParam(':id', $user_id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Puan kaydedilemedi.']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Geçersiz istek.']);
}
?>
