<?php 
  session_start();
  if (isset($_SESSION['id']) && isset($_SESSION['username']) ) {
    header("Location: index.php?message=You are already logged in!");
  }

?>


<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giriş Yap</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app">
<h2 style="text-align: center;">Giriş Yap</h2>
    <form action="girişSayfası.php" method="POST">
        <label for="username">Kullanıcı Adı:</label><br>
        <input type="text" id="buttonLogin" name="username" placeholder="Kullanıcı adınızı girin..." required>
        <br><br>
        <label for="password">Şifre:</label><br>
        <input type="password" id="buttonLogin" name="password" placeholder="Şifrenizi girin..." required>
        <br><br>
        <button type="submit" class="button2">Giriş Yap</button>
        <a href="kayıtSayfası.html" class="button2">Kayıt Ol</a>
    </form>
</body>
</html>
