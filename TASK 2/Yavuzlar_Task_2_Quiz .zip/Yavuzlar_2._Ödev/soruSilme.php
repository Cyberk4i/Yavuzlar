<?php

if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];


    include 'quiz_data.php';


    if (isset($pdo)) {

        $query = "DELETE FROM questions WHERE id = :id";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':id', $delete_id, PDO::PARAM_INT);


        if ($stmt->execute()) {
            echo "Soru başarıyla silindi.<br>";
            echo '<form action="soruListele.php" method="get">';
            echo '<button type="submit">Geri Dön</button>';
            echo '</form>';
            exit();

        } else {
            echo "Soru silinirken bir hata oluştu." ;
            echo '<form action="soruListele.php" method="get">';
            echo '<button type="submit">Geri Dön</button>';
            echo '</form>';
            exit();
        }
    } else {

        echo "Veritabanı bağlantısında sorun var.";
        echo '<form action="soruListele.php" method="get">';
        echo '<button type="submit">Geri Dön</button>';
        echo '</form>';
        exit();
        
    }
}
?>
