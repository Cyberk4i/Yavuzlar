<?php
include 'quiz_data.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $isAdmin = $_POST['isAdmin'];


    $query = "INSERT INTO users (username, password, isAdmin) 
              VALUES (:username, :password, :isAdmin)";
    
    $statement = $pdo->prepare($query);

    $statement->execute([
        ':username' => $username,
        ':password' => $password,
        ':isAdmin' => $isAdmin,
    ]);

    echo "Kullanıcı başarıyla kaydedildi!";
} else {
    echo "Kaydedilecek veri yok.";
}

?>