<?php
include 'quiz_data.php';

$searchResults = [];
if (isset($_GET['searchInput']) && !empty($_GET['searchInput'])) {
    $searchInput = $_GET['searchInput'];
    
    $stmt = $pdo->prepare("SELECT * FROM questions WHERE soru LIKE :searchInput");
    $stmt->execute(['searchInput' => "%$searchInput%"]);
    $searchResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="tr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Soru Ara</title>
  
  <link rel="stylesheet" href="style.css">
</head>

<body>

  <div class="searchResults"> 
    <h1>Soru Ara</h1>
    
    <form id="searchForm" method="get" action="">
      <label for="searchInput">Soru Ara:</label><br>
      <input type="text" id="searchInput" name="searchInput" class="button3" placeholder="Anahtar kelimeyi girin" required><br><br>
      
      <button type="submit" class="button2">Ara</button>
    </form>
    <br>
      <h1>Sonuç</h1>
      <table>
        <thead>
          <tr>
            <th>Kaçıncı soru</th>
            <th>Soru</th>
            <th>Cevap 1</th>
            <th>Cevap 2</th>
            <th>Cevap 3</th>
            <th>Cevap 4</th>
            <th>Doğru Cevap</th>
            <th>Zorluk</th>
          </tr>
        </thead>
        <tbody>
        <?php if (empty($searchResults)): ?>
          <tr>
            <td colspan="8">Sonuç bulunamadı.</td>
          </tr>
        <?php else: ?>
          <?php foreach ($searchResults as $row): ?>
            <tr>
              <td><?php echo htmlspecialchars($row['id']); ?></td>
              <td><?php echo htmlspecialchars($row['soru']); ?></td>
              <td><?php echo htmlspecialchars($row['cevap1']); ?></td>
              <td><?php echo htmlspecialchars($row['cevap2']); ?></td>
              <td><?php echo htmlspecialchars($row['cevap3']); ?></td>
              <td><?php echo htmlspecialchars($row['cevap4']); ?></td>
              <td><?php echo htmlspecialchars($row['dogru_cevap']); ?></td>
              <td><?php echo htmlspecialchars($row['zorluk']); ?></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
      </table>
    
    <br>
    <a href="soruListele.php" class="button2">Geri Dön</a>
  </div>

</body>

</html>
