<?php
  session_start();
  ?>

  <!DOCTYPE html>
  <html lang="tr">

  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anasayfa</title>
    <link rel="stylesheet" href="style.css">
  </head>

  <body>

    <div class="app">
      
      <div class="header">
        <h1>Yavuzlar Takımı Quiz Sistemi</h1>
      </div>
      <a href="quiz.php" class="button2">Quizi Başlat</a>
      <?php if ($_SESSION['isAdmin']):?>
        <a href="soruListele.php">
          <div class="button2">
            Soruları Düzenle
          </div>
        </a>
        <?php endif?>
        
        



  </body>

  </html>
