<?php
function getQuestions() {
    global $pdo;
    
    $stmt = $pdo->query('SELECT * FROM questions');
    $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);


    shuffle($questions);

    $formattedQuestions = array_map(function($q) {

        $answers = [
            ['text' => $q['cevap1'], 'index' => 1],
            ['text' => $q['cevap2'], 'index' => 2],
            ['text' => $q['cevap3'], 'index' => 3],
            ['text' => $q['cevap4'], 'index' => 4]
        ];
        shuffle($answers);

        return [
            'question' => $q['soru'],
            'difficulty' => $q['zorluk'],
            'answers' => $answers,
            'rightAnswer' => array_search($q['dogru_cevap'], array_column($answers, 'index')) + 1,
            'id' => $q['id']
        ];
    }, $questions);

    return $formattedQuestions;
}

function Login($username,$password){

    include "quiz_users_data.php";

    $query = "SELECT *,COUNT(*) as count FROM users WHERE username = :username AND password = :password";

    $statement = $pdo->prepare($query);

    $statement->execute(['username' => $username, 'password' => $password]);

    $result = $statement->fetch();

    return $result;
}

function soruKaydi($username)

?>
