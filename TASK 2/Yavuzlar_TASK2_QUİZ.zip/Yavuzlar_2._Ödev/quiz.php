<?php

include 'quiz_data.php';
include 'quiz_functions.php';

$questions = getQuestions();

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Quiz Uygulaması</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="app">
        <h1>Yavuzlar Başarılar Diler... <br></h1>
        <div class="quiz">               
            <h2 id="question">Soru buraya geliyor</h2>
            <div id="answer-buttons">
                <button class="button1">cevap1</button>
                <button class="button1">cevap2</button>
                <button class="button1">cevap3</button>
                <button class="button1">cevap4</button>
            </div>
            <button id="skip-question-button" class="skip-button">Boş Bırak</button>
            <button id="next-question-button">Sonraki Soru</button>
            <button id="home-button" style="display: none;">Ana Sayfaya Dön</button>
            <div id="difficulty">Zorluk: </div>
        </div>
    </div>
    <script>
        const questions = <?php echo json_encode($questions); ?>;
        let currentIndex = 0;
        let score = 0;

        const questionElement = document.getElementById("question");
        const difficultyElement = document.getElementById("difficulty");
        const answerButtons = document.getElementById("answer-buttons");
        const nextButton = document.getElementById("next-question-button");
        const skipButton = document.getElementById("skip-question-button");
        const homeButton = document.getElementById("home-button");

        function startQuiz() {
            currentIndex = 0;
            score = 0;
            nextButton.innerHTML = "Sonraki Soru";
            showQuestion();
        }

        function showQuestion() {
            resetState();
            let currentQuestion = questions[currentIndex]
            let questionNumber = currentIndex + 1;
            questionElement.innerHTML = questionNumber + ". " + currentQuestion.question;
            let difficultyName = getScoreByDifficultyStr(currentQuestion.difficulty);
            let difficultyScore = getScoreByDifficulty(currentQuestion.difficulty);

            difficultyElement.innerHTML = `Zorluk: ${difficultyName}<br>Puan: ${difficultyScore}<br>Toplam Puan: ${score}`;

            currentQuestion.answers.forEach(answer => {
                const button = document.createElement("button");
                button.innerHTML = answer.text;
                button.classList.add("button1");
                answerButtons.appendChild(button);
                button.dataset.index = answer.index;
                button.addEventListener("click", selectAnswer);
            });

            skipButton.style.display = "block";
            skipButton.disabled = false;
        }

        function resetState() {
            nextButton.style.display = "none";
            skipButton.style.display = "none";
            while (answerButtons.firstChild) {
                answerButtons.removeChild(answerButtons.firstChild);
            }
        }

        function selectAnswer(e) {
            const selectedButton = e.target;
            const selectedIndex = selectedButton.dataset.index;
            const correctIndex = questions[currentIndex].rightAnswer;

            if (selectedIndex == correctIndex) {
                selectedButton.classList.add("correct");
                score += getScoreByDifficulty(questions[currentIndex].difficulty);
            } else {
                selectedButton.classList.add("incorrect");
                Array.from(answerButtons.children).forEach(button => {
                    if (button.dataset.index == correctIndex) {
                        button.classList.add("correct");
                    }
                });
            }

            Array.from(answerButtons.children).forEach(button => {
                button.disabled = true;
            });

            if (currentIndex < questions.length - 1) {
                nextButton.innerHTML = "Sonraki Soru";
                nextButton.style.display = "block";
            } else {
                nextButton.innerHTML = "Sınavı Bitir";
                nextButton.style.display = "block";
            }

            skipButton.disabled = true;
        }

        function getScoreByDifficulty(difficulty) {
            switch (difficulty) {
                case "easy":
                    return 1;
                case "medium":
                    return 2;
                case "hard":
                    return 3;
                default:
                    return 0;
            }
        }

        function getScoreByDifficultyStr(difficulty) {
            switch (difficulty) {
                case "easy":
                    return "Kolay";
                case "medium":
                    return "Orta";
                case "hard":
                    return "Zor";
                default:
                    return "";
            }
        }

        function showScore() {
            resetState();
            questionElement.innerHTML = `Quiz bitti. ${questions.length} sorudan puanınız: ${score}`;
            difficultyElement.innerHTML = "";
            nextButton.innerHTML = "Tekrar Dene";
            nextButton.style.display = "block";
            homeButton.style.display = "block";
        }

        function handleNextButton() {
            currentIndex++;
            if (currentIndex < questions.length) {
                showQuestion();
            } else {
                showScore();
            }
        }

        function skipQuestion() {
            handleNextButton();
        }

        function cozulenSoru() {





        }

        nextButton.addEventListener("click", () => {
            if (currentIndex < questions.length) {
                handleNextButton();
            } else {
                startQuiz();
                homeButton.style.display = "none";
            }
        });

        skipButton.addEventListener("click", skipQuestion);

        homeButton.addEventListener("click", () => {
            window.location.href = 'anaSayfa.php';
        });


        startQuiz();
    </script>
</body>
</html>
