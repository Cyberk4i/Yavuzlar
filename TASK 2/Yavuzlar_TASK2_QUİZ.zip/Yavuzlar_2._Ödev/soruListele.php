<?php
include 'quiz_data.php';

$query = "SELECT * FROM questions";
$statement = $pdo->query($query);

$questions = $statement->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="tr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Soru Listesi</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>

  <div class="questList">
    <a href="soruAra.php" class="button2">Soru Ara</a>
    <table>
      <thead>
        <tr>
          <th>Kaçıncı soru</th>
          <th>Soru</th>
          <th>Cevap 1</th>
          <th>Cevap 2</th>
          <th>Cevap 3</th>
          <th>Cevap 4</th>
          <th>Doğru Cevap</th>
          <th>Zorluk</th>
          <th>Soruyu Düzenle</th>
          <th>Soruyu Sil</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($questions as $question): ?>
          <tr>
            <td><?php echo $question['id']; ?></td>
            <td><?php echo $question['soru']; ?></td>
            <td><?php echo $question['cevap1']; ?></td>
            <td><?php echo $question['cevap2']; ?></td>
            <td><?php echo $question['cevap3']; ?></td>
            <td><?php echo $question['cevap4']; ?></td>
            <td><?php echo $question['dogru_cevap']; ?></td>
            <td><?php echo $question['zorluk']; ?></td>
            <td><a href="soruDüzenle.php?id=<?php echo $question['id']; ?>" class="button4">Düzenle</a></td>
            <td><a href="?delete_id=<?php echo $question['id']; ?>" class="button4" onclick="return confirm('Bu soruyu silmek istediğinize emin misiniz?');">Sil</a></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <a href="soruEkle.html" class="button2">Soru Ekle</a>
    <a href="anaSayfa.php" class="button2">Ana Sayfaya Git</a>
  </div>

</body>

</html>
